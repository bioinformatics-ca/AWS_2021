grep "/locus_tag=" "$1" | head -n "$2" | tail -n "$3"
